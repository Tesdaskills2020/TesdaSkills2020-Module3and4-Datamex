﻿Public Class InstitutionsViewinfo
    Friend iden As Integer
    Friend insid As Integer


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles editbtn.Click

    End Sub

    Private Sub InstitutionsViewinfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        scholarload()
        '

    End Sub
    Public Sub INstituteload()
        Dim sql As String = "select Region.id,Region.Name,Province.Name, Municipality.City , Municipality.DistrictNumber , Institutions.InstitutionName , Institutions.Classification ,Institutions.Address ,Institutions.InstitutionType
        ,Institutions.TelNo,Institutions.EmailAddress, Institutions.AdminName,Institutions.Designation  from  ((((Region inner join Province on Province.RegionID = region.id) inner join
Municipality on Municipality.ProvinceID = Province.Id) inner join Institutions on Institutions.municipalityID = Municipality.id) )where Municipality.city = '" + InstitutionMain.citycmb.Text + "' "


        con = New SqlClient.SqlConnection(m2)

        com = New SqlClient.SqlCommand(sql, con)

        Dim mr As SqlClient.SqlDataReader
        mr = com.ExecuteReader
        mr.Read()



        iden = mr("id")

        insnamelbl.Text = mr("InstitutionName")
        regionlbl.Text = mr("Name")
        Provlbl.Text = mr("Province.Name")
        citylbl.Text = mr("City")
        DNlbl.Text = mr("DistrictNumber")
        classlbl.Text = mr("Classification")
        albl.Text = mr("Address")
        itlbl.Text = mr("InstitutionType")
        tllbl.Text = mr("TelNo")
        ealbl.Text = mr("EmailAddress")
        anlbl.Text = mr("AdminName")
        desiglbl.Text = mr("Designation")
    End Sub
    Private Sub addprogbtn_Click(sender As Object, e As EventArgs) Handles addprogbtn.Click
        QualifiADD.Show()
        Me.Hide()

    End Sub

    Private Sub addtrainerbtn_Click(sender As Object, e As EventArgs) Handles addtrainerbtn.Click
        addtrainer.Show()
        Me.Hide()

    End Sub
    Public Sub scholarload()

        con = New SqlClient.SqlConnection(m3)
        Try
            'Dim sql As String = "select Sectors(SectorName), Qualifications(QualificationName), RegisteredPrograms.Duration, RegisteredPrograms.ProgramRegistrationNumber from (Sectors inner join dbo.Qualifications on Qualifications(SectorID) = Sectors(Id)) Qualification  Inner join RegisteredPrograms on RegisteredPrograms(QualificationID) = Qualification(Id)"
            ' Dim sql As String = "select SectorName,QualificationName,Duration,ProgramRegistrationNumber From [dbo].[Sectors],[dbo].[Qualifications],[dbo].[RegisteredPrograms] Where [dbo].[Qualifications].(SectersID) = [dbo].[Sectors].(Id) And [dbo].[RegisteredPrograms].(QualificationID) = [dbo].[Qualifications].(Id)"
            Dim sql As String = "select Sectors.SectorName, Qualifications.QualificationName, RegisteredPrograms.ProgramRegistrationNumber, RegisteredPrograms.Duration from ((Sectors inner join Qualifications on Qualifications.SectorID = Sectors.id)  inner join RegisteredPrograms on RegisteredPrograms.QualificationID = Qualifications.id ) 
"
            Dim adpt As New SqlClient.SqlDataAdapter(Sql, con)

            Dim ds As New DataSet


            adpt.Fill(ds)
            scholarview.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try

    End Sub
End Class