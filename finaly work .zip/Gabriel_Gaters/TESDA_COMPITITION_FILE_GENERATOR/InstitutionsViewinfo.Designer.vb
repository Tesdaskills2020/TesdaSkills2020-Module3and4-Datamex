﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InstitutionsViewinfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.insnamelbl = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.itlbl = New System.Windows.Forms.Label()
        Me.DNlbl = New System.Windows.Forms.Label()
        Me.Provlbl = New System.Windows.Forms.Label()
        Me.desiglbl = New System.Windows.Forms.Label()
        Me.anlbl = New System.Windows.Forms.Label()
        Me.ealbl = New System.Windows.Forms.Label()
        Me.tllbl = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.albl = New System.Windows.Forms.Label()
        Me.classlbl = New System.Windows.Forms.Label()
        Me.citylbl = New System.Windows.Forms.Label()
        Me.regionlbl = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.scholarview = New System.Windows.Forms.DataGridView()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.doculistbtn = New System.Windows.Forms.Button()
        Me.editbtn = New System.Windows.Forms.Button()
        Me.addprogbtn = New System.Windows.Forms.Button()
        Me.addtrainerbtn = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.scholarview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.insnamelbl)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1205, 69)
        Me.Panel1.TabIndex = 0
        '
        'insnamelbl
        '
        Me.insnamelbl.AutoSize = True
        Me.insnamelbl.Location = New System.Drawing.Point(33, 25)
        Me.insnamelbl.Name = "insnamelbl"
        Me.insnamelbl.Size = New System.Drawing.Size(98, 15)
        Me.insnamelbl.TabIndex = 0
        Me.insnamelbl.Text = "INstitution Name"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.itlbl)
        Me.Panel2.Controls.Add(Me.DNlbl)
        Me.Panel2.Controls.Add(Me.Provlbl)
        Me.Panel2.Controls.Add(Me.desiglbl)
        Me.Panel2.Controls.Add(Me.anlbl)
        Me.Panel2.Controls.Add(Me.ealbl)
        Me.Panel2.Controls.Add(Me.tllbl)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.albl)
        Me.Panel2.Controls.Add(Me.classlbl)
        Me.Panel2.Controls.Add(Me.citylbl)
        Me.Panel2.Controls.Add(Me.regionlbl)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 69)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1205, 263)
        Me.Panel2.TabIndex = 1
        '
        'itlbl
        '
        Me.itlbl.AutoSize = True
        Me.itlbl.Location = New System.Drawing.Point(551, 132)
        Me.itlbl.Name = "itlbl"
        Me.itlbl.Size = New System.Drawing.Size(28, 15)
        Me.itlbl.TabIndex = 23
        Me.itlbl.Text = "XXX"
        Me.itlbl.UseWaitCursor = True
        '
        'DNlbl
        '
        Me.DNlbl.AutoSize = True
        Me.DNlbl.Location = New System.Drawing.Point(551, 84)
        Me.DNlbl.Name = "DNlbl"
        Me.DNlbl.Size = New System.Drawing.Size(28, 15)
        Me.DNlbl.TabIndex = 22
        Me.DNlbl.Text = "XXX"
        Me.DNlbl.UseWaitCursor = True
        '
        'Provlbl
        '
        Me.Provlbl.AutoSize = True
        Me.Provlbl.Location = New System.Drawing.Point(551, 29)
        Me.Provlbl.Name = "Provlbl"
        Me.Provlbl.Size = New System.Drawing.Size(28, 15)
        Me.Provlbl.TabIndex = 21
        Me.Provlbl.Text = "XXX"
        Me.Provlbl.UseWaitCursor = True
        '
        'desiglbl
        '
        Me.desiglbl.AutoSize = True
        Me.desiglbl.Location = New System.Drawing.Point(858, 182)
        Me.desiglbl.Name = "desiglbl"
        Me.desiglbl.Size = New System.Drawing.Size(28, 15)
        Me.desiglbl.TabIndex = 20
        Me.desiglbl.Text = "XXX"
        '
        'anlbl
        '
        Me.anlbl.AutoSize = True
        Me.anlbl.Location = New System.Drawing.Point(858, 132)
        Me.anlbl.Name = "anlbl"
        Me.anlbl.Size = New System.Drawing.Size(28, 15)
        Me.anlbl.TabIndex = 19
        Me.anlbl.Text = "XXX"
        '
        'ealbl
        '
        Me.ealbl.AutoSize = True
        Me.ealbl.Location = New System.Drawing.Point(858, 84)
        Me.ealbl.Name = "ealbl"
        Me.ealbl.Size = New System.Drawing.Size(28, 15)
        Me.ealbl.TabIndex = 18
        Me.ealbl.Text = "XXX"
        '
        'tllbl
        '
        Me.tllbl.AutoSize = True
        Me.tllbl.Location = New System.Drawing.Point(858, 29)
        Me.tllbl.Name = "tllbl"
        Me.tllbl.Size = New System.Drawing.Size(28, 15)
        Me.tllbl.TabIndex = 17
        Me.tllbl.Text = "XXX"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(729, 182)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(81, 15)
        Me.Label14.TabIndex = 16
        Me.Label14.Text = "DESIGNATION"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(729, 132)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(46, 15)
        Me.Label15.TabIndex = 15
        Me.Label15.Text = "ADMIN"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(729, 84)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(41, 15)
        Me.Label16.TabIndex = 14
        Me.Label16.Text = "EMAIL"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(729, 29)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(55, 15)
        Me.Label17.TabIndex = 13
        Me.Label17.Text = "TELL NO."
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(379, 132)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(33, 15)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "TYPE"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(379, 84)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(152, 15)
        Me.Label12.TabIndex = 10
        Me.Label12.Text = "CONGRRESIONAL DISTRICT"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(379, 29)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(115, 15)
        Me.Label13.TabIndex = 9
        Me.Label13.Text = "PROVINCE/DISTRICT"
        '
        'albl
        '
        Me.albl.AutoSize = True
        Me.albl.Location = New System.Drawing.Point(168, 182)
        Me.albl.Name = "albl"
        Me.albl.Size = New System.Drawing.Size(28, 15)
        Me.albl.TabIndex = 8
        Me.albl.Text = "XXX"
        Me.albl.UseWaitCursor = True
        '
        'classlbl
        '
        Me.classlbl.AutoSize = True
        Me.classlbl.Location = New System.Drawing.Point(168, 132)
        Me.classlbl.Name = "classlbl"
        Me.classlbl.Size = New System.Drawing.Size(28, 15)
        Me.classlbl.TabIndex = 7
        Me.classlbl.Text = "XXX"
        Me.classlbl.UseWaitCursor = True
        '
        'citylbl
        '
        Me.citylbl.AutoSize = True
        Me.citylbl.Location = New System.Drawing.Point(168, 84)
        Me.citylbl.Name = "citylbl"
        Me.citylbl.Size = New System.Drawing.Size(28, 15)
        Me.citylbl.TabIndex = 6
        Me.citylbl.Text = "XXX"
        Me.citylbl.UseWaitCursor = True
        '
        'regionlbl
        '
        Me.regionlbl.AutoSize = True
        Me.regionlbl.Location = New System.Drawing.Point(168, 29)
        Me.regionlbl.Name = "regionlbl"
        Me.regionlbl.Size = New System.Drawing.Size(28, 15)
        Me.regionlbl.TabIndex = 5
        Me.regionlbl.Text = "XXX"
        Me.regionlbl.UseWaitCursor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 182)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 15)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "ADDRESS"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(33, 132)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "CLASS"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(33, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "MUNICIPALITY"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "REGION"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.scholarview)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 332)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1205, 201)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "LIST OF SCHOLARSHIP PROGRAM"
        '
        'scholarview
        '
        Me.scholarview.AllowUserToAddRows = False
        Me.scholarview.AllowUserToDeleteRows = False
        Me.scholarview.AllowUserToResizeColumns = False
        Me.scholarview.AllowUserToResizeRows = False
        Me.scholarview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.scholarview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.scholarview.Dock = System.Windows.Forms.DockStyle.Fill
        Me.scholarview.Location = New System.Drawing.Point(3, 19)
        Me.scholarview.Name = "scholarview"
        Me.scholarview.ReadOnly = True
        Me.scholarview.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.scholarview.RowTemplate.Height = 25
        Me.scholarview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.scholarview.Size = New System.Drawing.Size(1199, 179)
        Me.scholarview.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.DataGridView2)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox2.Location = New System.Drawing.Point(0, 533)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1205, 194)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "LIST OF CERTIFIED TRAINERS"
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.AllowUserToResizeColumns = False
        Me.DataGridView2.AllowUserToResizeRows = False
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.DataGridView2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView2.Enabled = False
        Me.DataGridView2.Location = New System.Drawing.Point(3, 19)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        Me.DataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.DataGridView2.RowTemplate.Height = 25
        Me.DataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView2.Size = New System.Drawing.Size(1199, 172)
        Me.DataGridView2.TabIndex = 0
        '
        'doculistbtn
        '
        Me.doculistbtn.Location = New System.Drawing.Point(12, 740)
        Me.doculistbtn.Name = "doculistbtn"
        Me.doculistbtn.Size = New System.Drawing.Size(217, 27)
        Me.doculistbtn.TabIndex = 4
        Me.doculistbtn.Text = "&DOCUMENT CHECKLIST"
        Me.doculistbtn.UseVisualStyleBackColor = True
        '
        'editbtn
        '
        Me.editbtn.Location = New System.Drawing.Point(235, 740)
        Me.editbtn.Name = "editbtn"
        Me.editbtn.Size = New System.Drawing.Size(217, 27)
        Me.editbtn.TabIndex = 5
        Me.editbtn.Text = "&EDIT INSTITUTIONS INFO"
        Me.editbtn.UseVisualStyleBackColor = True
        '
        'addprogbtn
        '
        Me.addprogbtn.Location = New System.Drawing.Point(458, 740)
        Me.addprogbtn.Name = "addprogbtn"
        Me.addprogbtn.Size = New System.Drawing.Size(217, 27)
        Me.addprogbtn.TabIndex = 6
        Me.addprogbtn.Text = "&ADD SCHOLARSHIP PROGRAM"
        Me.addprogbtn.UseVisualStyleBackColor = True
        '
        'addtrainerbtn
        '
        Me.addtrainerbtn.Location = New System.Drawing.Point(681, 740)
        Me.addtrainerbtn.Name = "addtrainerbtn"
        Me.addtrainerbtn.Size = New System.Drawing.Size(217, 27)
        Me.addtrainerbtn.TabIndex = 7
        Me.addtrainerbtn.Text = "ADD &TRAINER"
        Me.addtrainerbtn.UseVisualStyleBackColor = True
        '
        'InstitutionsViewinfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1205, 779)
        Me.Controls.Add(Me.addtrainerbtn)
        Me.Controls.Add(Me.addprogbtn)
        Me.Controls.Add(Me.editbtn)
        Me.Controls.Add(Me.doculistbtn)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "InstitutionsViewinfo"
        Me.Text = "InstitutionsViewinfo"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.scholarview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents insnamelbl As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents itlbl As Label
    Friend WithEvents DNlbl As Label
    Friend WithEvents Provlbl As Label
    Friend WithEvents desiglbl As Label
    Friend WithEvents anlbl As Label
    Friend WithEvents ealbl As Label
    Friend WithEvents tllbl As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents albl As Label
    Friend WithEvents classlbl As Label
    Friend WithEvents citylbl As Label
    Friend WithEvents regionlbl As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents scholarview As DataGridView
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents doculistbtn As Button
    Friend WithEvents editbtn As Button
    Friend WithEvents addprogbtn As Button
    Friend WithEvents addtrainerbtn As Button
End Class
