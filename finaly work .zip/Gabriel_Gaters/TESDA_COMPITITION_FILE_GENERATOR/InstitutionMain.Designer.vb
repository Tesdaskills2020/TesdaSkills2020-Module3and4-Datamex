﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class InstitutionMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.userstrip = New System.Windows.Forms.Panel()
        Me.editbtn = New System.Windows.Forms.Button()
        Me.addbtn = New System.Windows.Forms.Button()
        Me.logbtn = New System.Windows.Forms.Button()
        Me.usrbtn = New System.Windows.Forms.Button()
        Me.intsbtn = New System.Windows.Forms.Button()
        Me.filebtn = New System.Windows.Forms.Button()
        Me.InstitutionVIew = New System.Windows.Forms.DataGridView()
        Me.FIlterGB = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.citycmb = New System.Windows.Forms.ComboBox()
        Me.provcmb = New System.Windows.Forms.ComboBox()
        Me.regcmb = New System.Windows.Forms.ComboBox()
        Me.VIEWBTN = New System.Windows.Forms.Button()
        Me.fillbtn = New System.Windows.Forms.Button()
        Me.userstrip.SuspendLayout()
        CType(Me.InstitutionVIew, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FIlterGB.SuspendLayout()
        Me.SuspendLayout()
        '
        'userstrip
        '
        Me.userstrip.Controls.Add(Me.editbtn)
        Me.userstrip.Controls.Add(Me.addbtn)
        Me.userstrip.Location = New System.Drawing.Point(240, 54)
        Me.userstrip.Name = "userstrip"
        Me.userstrip.Size = New System.Drawing.Size(120, 71)
        Me.userstrip.TabIndex = 21
        Me.userstrip.Visible = False
        '
        'editbtn
        '
        Me.editbtn.Dock = System.Windows.Forms.DockStyle.Top
        Me.editbtn.Location = New System.Drawing.Point(0, 36)
        Me.editbtn.Name = "editbtn"
        Me.editbtn.Size = New System.Drawing.Size(120, 36)
        Me.editbtn.TabIndex = 12
        Me.editbtn.Text = "EDIT USERS"
        Me.editbtn.UseVisualStyleBackColor = True
        '
        'addbtn
        '
        Me.addbtn.Dock = System.Windows.Forms.DockStyle.Top
        Me.addbtn.Location = New System.Drawing.Point(0, 0)
        Me.addbtn.Name = "addbtn"
        Me.addbtn.Size = New System.Drawing.Size(120, 36)
        Me.addbtn.TabIndex = 11
        Me.addbtn.Text = "ADD USERS"
        Me.addbtn.UseVisualStyleBackColor = True
        '
        'logbtn
        '
        Me.logbtn.Location = New System.Drawing.Point(360, 12)
        Me.logbtn.Name = "logbtn"
        Me.logbtn.Size = New System.Drawing.Size(110, 36)
        Me.logbtn.TabIndex = 15
        Me.logbtn.Text = "log-out"
        Me.logbtn.UseVisualStyleBackColor = True
        '
        'usrbtn
        '
        Me.usrbtn.Location = New System.Drawing.Point(244, 12)
        Me.usrbtn.Name = "usrbtn"
        Me.usrbtn.Size = New System.Drawing.Size(110, 36)
        Me.usrbtn.TabIndex = 14
        Me.usrbtn.Text = "users"
        Me.usrbtn.UseVisualStyleBackColor = True
        '
        'intsbtn
        '
        Me.intsbtn.Location = New System.Drawing.Point(128, 12)
        Me.intsbtn.Name = "intsbtn"
        Me.intsbtn.Size = New System.Drawing.Size(110, 36)
        Me.intsbtn.TabIndex = 13
        Me.intsbtn.Text = "institution"
        Me.intsbtn.UseVisualStyleBackColor = True
        '
        'filebtn
        '
        Me.filebtn.Location = New System.Drawing.Point(12, 12)
        Me.filebtn.Name = "filebtn"
        Me.filebtn.Size = New System.Drawing.Size(110, 36)
        Me.filebtn.TabIndex = 12
        Me.filebtn.Text = "file"
        Me.filebtn.UseVisualStyleBackColor = True
        '
        'InstitutionVIew
        '
        Me.InstitutionVIew.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.InstitutionVIew.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.InstitutionVIew.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.InstitutionVIew.Location = New System.Drawing.Point(12, 213)
        Me.InstitutionVIew.Name = "InstitutionVIew"
        Me.InstitutionVIew.RowTemplate.Height = 25
        Me.InstitutionVIew.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.InstitutionVIew.Size = New System.Drawing.Size(969, 319)
        Me.InstitutionVIew.TabIndex = 11
        '
        'FIlterGB
        '
        Me.FIlterGB.Controls.Add(Me.Label3)
        Me.FIlterGB.Controls.Add(Me.Label2)
        Me.FIlterGB.Controls.Add(Me.Label1)
        Me.FIlterGB.Controls.Add(Me.citycmb)
        Me.FIlterGB.Controls.Add(Me.provcmb)
        Me.FIlterGB.Controls.Add(Me.regcmb)
        Me.FIlterGB.Location = New System.Drawing.Point(12, 131)
        Me.FIlterGB.Name = "FIlterGB"
        Me.FIlterGB.Size = New System.Drawing.Size(969, 76)
        Me.FIlterGB.TabIndex = 22
        Me.FIlterGB.TabStop = False
        Me.FIlterGB.Text = "Filter BY:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(625, 40)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(120, 15)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "CITTY/MUNICIPALITY"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(290, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(109, 15)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "PROVINCE/DISTRIC"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 15)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "REGION "
        '
        'citycmb
        '
        Me.citycmb.FormattingEnabled = True
        Me.citycmb.Items.AddRange(New Object() {"Bangued", "Boliney", "Bucay", "Bucloc", "Daguioman", "Danglas", "Dolores", "La Paz", "Lacub", "Lagangilang", "Lagayan", "Langiden", "Licuan-Baay", "Luba", "Malibcong", "Manabo", "Peñarrubia", "Pidigan", "Pilar", "Sallapadan", "San Isidro", "San Juan", "San Quintin", "Tayum", "Tineg", "Tubo", "Villaviciosa", "Buenavista", "Carmen", "Jabonga", "Kitcharao", "Las Nieves", "Magallanes", "Nasipit", "Remedios T. Romualdez", "Santiago", "Tubay", "Bunawan", "Esperanza", "La Paz", "Loreto", "Prosperidad", "Rosario", "San Francisco", "San Luis", "Santa Josefa", "Sibagat", "Talacogon", "Trento", "Veruela", "Altavas", "Balete", "Banga", "Batan", "Buruanga", "Ibajay", "Kalibo", "Lezo", "Libacao", "Madalag", "Makato", "Malay", "Malinao", "Nabas", "New Washington", "Numancia", "Tangalan", "Bacacay", "Camalig", "Daraga", "Guinobatan", "Jovellar", "Libon", "Malilipot", "Malinao", "Manito", "Oas", "Pio Duran", "Polangui", "Rapu-Rapu", "Santo Domingo", "Tiwi", "Anini-y", "Barbaza", "Belison", "Bugasong", "Caluya", "Culasi", "Hamtic", "Laua-an", "Libertad", "Pandan", "Patnongon", "San Jose", "San Remigio", "Sebaste", "Sibalom", "Tibiao", "Tobias Fornier", "Valderrama", "Calanasan", "Conner", "Flora", "Kabugao", "Luna", "Pudtol", "Santa Marcela", "Baler", "Casiguran", "Dilasag", "Dinalungan", "Dingalan", "Dipaculao", "Maria Aurora", "San Luis", "Akbar", "Al-Barka", "Hadji Mohammad Ajul", "Hadji Muhtamad", "Lantawan", "Maluso", "Sumisip", "Tabuan-Lasa", "Tipo-Tipo", "Tuburan", "Ungkaya Pukan", "Abucay", "Bagac", "Dinalupihan", "Hermosa", "Limay", "Mariveles", "Morong", "Orani", "Orion", "Pilar", "Samal", "Basco", "Itbayat", "Ivana", "Mahatao", "Sabtang", "Uyugan", "Agoncillo", "Alitagtag", "Balayan", "Balete", "Bauan", "Calaca", "Calatagan", "Cuenca", "Ibaan", "Laurel", "Lemery", "Lian", "Lobo", "Mabini", "Malvar", "Mataasnakahoy", "Nasugbu", "Padre Garcia", "Rosario", "San Jose", "San Juan", "San Luis", "San Nicolas", "San Pascual", "Santa Teresita", "Santo Tomas", "Taal", "Talisay", "Taysan", "Tingloy", "Tuy", "Atok", "Bakun", "Bokod", "Buguias", "Itogon", "Kabayan", "Kapangan", "Kibungan", "La Trinidad", "Mankayan", "Sablan", "Tuba", "Tublay", "Almeria", "Biliran", "Cabucgayan", "Caibiran", "Culaba", "Kawayan", "Maripipi", "Naval", "Alburquerque", "Alicia", "Anda", "Antequera", "Baclayon", "Balilihan", "Batuan", "Bien Unido", "Bilar", "Buenavista", "Calape", "Candijay", "Carmen", "Catigbian", "Clarin", "Corella", "Cortes", "Dagohoy", "Danao", "Dauis", "Dimiao", "Duero", "Garcia Hernandez", "Getafe", "Guindulman", "Inabanga", "Jagna", "Lila", "Loay", "Loboc", "Loon", "Mabini", "Maribojoc", "Panglao", "Pilar", "President Carlos P. Garcia", "Sagbayan", "San Isidro", "San Miguel", "Sevilla", "Sierra Bullones", "Sikatuna", "Talibon", "Trinidad", "Tubigon", "Ubay", "Valencia", "Baungon", "Cabanglasan", "Damulog", "Dangcagan", "Don Carlos", "Impasugong", "Kadingilan", "Kalilangan", "Kibawe", "Kitaotao", "Lantapan", "Libona", "Malitbog", "Manolo Fortich", "Maramag", "Pangantucan", "Quezon", "San Fernando", "Sumilao", "Talakag", "Angat", "Balagtas", "Baliuag", "Bocaue", "Bulakan", "Bustos", "Calumpit", "Doña Remedios Trinidad", "Guiguinto", "Hagonoy", "Marilao", "Norzagaray", "Obando", "Pandi", "Paombong", "Plaridel", "Pulilan", "San Ildefonso", "San Miguel", "San Rafael", "Santa Maria", "Abulug", "Alcala", "Allacapan", "Amulung", "Aparri", "Baggao", "Ballesteros", "Buguey", "Calayan", "Camalaniugan", "Claveria", "Enrile", "Gattaran", "Gonzaga", "Iguig", "Lal-lo", "Lasam", "Pamplona", "Peñablanca", "Piat", "Rizal", "Sanchez-Mira", "Santa Ana", "Santa Praxedes", "Santa Teresita", "Santo Niño", "Solana", "Tuao", "Basud", "Capalonga", "Daet", "Jose Panganiban", "Labo", "Mercedes", "Paracale", "San Lorenzo Ruiz", "San Vicente", "Santa Elena", "Talisay", "Vinzons", "Baao", "Balatan", "Bato", "Bombon", "Buhi", "Bula", "Cabusao", "Calabanga", "Camaligan", "Canaman", "Caramoan", "Del Gallego", "Gainza", "Garchitorena", "Goa", "Lagonoy", "Libmanan", "Lupi", "Magarao", "Milaor", "Minalabac", "Nabua", "Ocampo", "Pamplona", "Pasacao", "Pili", "Presentacion", "Ragay", "Sagñay", "San Fernando", "San Jose", "Sipocot", "Siruma", "Tigaon", "Tinambac", "Catarman", "Guinsiliban", "Mahinog", "Mambajao", "Sagay", "Cuartero", "Dao", "Dumalag", "Dumarao", "Ivisan", "Jamindan", "Maayon", "Mambusao", "Panay", "Panitan", "Pilar", "Pontevedra", "President Roxas", "Sapian", "Sigma", "Tapaz", "Bagamanoc", "Baras", "Bato", "Caramoran", "Gigmoto", "Pandan", "Panganiban", "San Andres", "San Miguel", "Viga", "Virac", "Alfonso", "Amadeo", "Carmona", "General Mariano Alvarez", "General Emilio Aguinaldo", "General Trias", "Indang", "Kawit", "Magallanes", "Maragondon", "Mendez", "Naic", "Noveleta", "Rosario", "Silang", "Tanza", "Ternate", "Alcantara", "Alcoy", "Alegria", "Aloguinsan", "Argao", "Asturias", "Badian", "Balamban", "Bantayan", "Barili", "Boljoon", "Borbon", "Carmen", "Catmon", "Compostela", "Consolacion", "Cordoba", "Daanbantayan", "Dalaguete", "Dumanjug", "Ginatilan", "Liloan", "Madridejos", "Malabuyoc", "Medellin", "Minglanilla", "Moalboal", "Oslob", "Pilar", "Pinamungajan", "Poro", "Ronda", "Samboan", "San Fernando", "San Francisco", "San Remigio", "Santa Fe", "Santander", "Sibonga", "Sogod", "Tabogon", "Tabuelan", "Tuburan", "Tudela", "Compostela", "Laak", "Mabini", "Maco", "Maragusan", "Mawab", "Monkayo", "Montevista", "Nabunturan", "New Bataan", "Pantukan", "Alamada", "Aleosan", "Antipas", "Arakan", "Banisilan", "Carmen", "Kabacan", "Libungan", "M'lang", "Magpet", "Makilala", "Matalam", "Midsayap", "Pigcawayan", "Pikit", "President Roxas", "Tulunan", "Asuncion", "Braulio E. Dujali", "Carmen", "Kapalong", "New Corella", "San Isidro", "Santo Tomas", "Talaingod", "Bansalan", "Hagonoy", "Kiblawan", "Magsaysay", "Malalag", "Matanao", "Padada", "Santa Cruz", "Sulop", "Don Marcelino", "Jose Abad Santos", "Malita", "Santa Maria", "Sarangani", "Baganga", "Banaybanay", "Boston", "Caraga", "Cateel", "Governor Generoso", "Lupon", "Manay", "San Isidro", "Tarragona", "Basilisa (Rizal)", "Cagdianao", "Dinagat", "Libjo (Albor)", "Loreto", "San Jose", "Tubajon", "Arteche", "Balangiga", "Balangkayan", "Can-avid", "Dolores", "General MacArthur", "Giporlos", "Guiuan", "Hernani", "Jipapad", "Lawaan", "Llorente", "Maslog", "Maydolong", "Mercedes", "Oras", "Quinapondan", "Salcedo", "San Julian", "San Policarpo", "Sulat", "Taft", "Buenavista", "Jordan", "Nueva Valencia", "San Lorenzo", "Sibunag", "Aguinaldo", "Alfonso Lista", "Asipulo", "Banaue", "Hingyon", "Hungduan", "Kiangan", "Lagawe", "Lamut", "Mayoyao", "Tinoc", "Adams", "Bacarra", "Badoc", "Bangui", "Banna", "Burgos", "Carasi", "Currimao", "Dingras", "Dumalneg", "Marcos", "Nueva Era", "Pagudpud", "Paoay", "Pasuquin", "Piddig", "Pinili", "San Nicolas", "Sarrat", "Solsona", "Vintar", "Alilem", "Banayoyo", "Bantay", "Burgos", "Cabugao", "Caoayan", "Cervantes", "Galimuyod", "Gregorio Del Pilar", "Lidlidda", "Magsingal", "Nagbukel", "Narvacan", "Quirino", "Salcedo", "San Emilio", "San Esteban", "San Ildefonso", "San Juan", "San Vicente", "Santa", "Santa Catalina", "Santa Cruz", "Santa Lucia", "Santa Maria", "Santiago", "Santo Domingo", "Sigay", "Sinait", "Sugpon", "Suyo", "Tagudin", "Ajuy", "Alimodian", "Anilao", "Badiangan", "Balasan", "Banate", "Barotac Nuevo", "Barotac Viejo", "Batad", "Bingawan", "Cabatuan", "Calinog", "Carles", "Concepcion", "Dingle", "Dueñas", "Dumangas", "Estancia", "Guimbal", "Igbaras", "Janiuay", "Lambunao", "Leganes", "Lemery", "Leon", "Maasin", "Miagao", "Mina", "New Lucena", "Oton", "Pavia", "Pototan", "San Dionisio", "San Enrique", "San Joaquin", "San Miguel", "San Rafael", "Santa Barbara", "Sara", "Tigbauan", "Tubungan", "Zarraga", "Alicia", "Angadanan", "Aurora", "Benito Soliven", "Burgos", "Cabagan", "Cabatuan", "Cordon", "Delfin Albano", "Dinapigue", "Divilacan", "Echague", "Gamu", "Jones", "Luna", "Maconacon", "Mallig", "Naguilian", "Palanan", "Quezon", "Quirino", "Ramon", "Reina Mercedes", "Roxas", "San Agustin", "San Guillermo", "San Isidro", "San Manuel", "San Mariano", "San Mateo", "San Pablo", "Santa Maria", "Santo Tomas", "Tumauini", "Balbalan", "Lubuagan", "Pasil", "Pinukpuk", "Rizal", "Tanudan", "Tinglayan", "Agoo", "Aringay", "Bacnotan", "Bagulin", "Balaoan", "Bangar", "Bauang", "Burgos", "Caba", "Luna", "Naguilian", "Pugo", "Rosario", "San Gabriel", "San Juan", "Santo Tomas", "Santol", "Sudipen", "Tubao", "Alaminos", "Bay", "Calauan", "Cavinti", "Famy", "Kalayaan", "Liliw", "Los Baños", "Luisiana", "Lumban", "Mabitac", "Magdalena", "Majayjay", "Nagcarlan", "Paete", "Pagsanjan", "Pakil", "Pangil", "Pila", "Rizal", "Santa Cruz", "Santa Maria", "Siniloan", "Victoria", "Bacolod", "Baloi", "Baroy", "Kapatagan", "Kauswagan", "Kolambugan", "Lala", "Linamon", "Magsaysay", "Maigo", "Matungao", "Munai", "Nunungan", "Pantao Ragat", "Pantar", "Poona Piagapo", "Salvador", "Sapad", "Sultan Naga Dimaporo", "Tagoloan", "Tangcal", "Tubod", "Bacolod-Kalawi", "Balabagan", "Balindong", "Bayang", "Binidayan", "Buadiposo-Buntong", "Bubong", "Bumbaran", "Butig", "Calanogas", "Ditsaan-Ramain", "Ganassi", "Kapai", "Kapatagan", "Lumba-Bayabao", "Lumbaca-Unayan", "Lumbatan", "Lumbayanague", "Madalum", "Madamba", "Maguing", "Malabang", "Marantao", "Marogong", "Masiu", "Mulondo", "Pagayawan", "Piagapo", "Poona Bayabao", "Pualas", "Saguiaran", "Sultan Dumalondong", "Picong", "Tagoloan II", "Tamparan", "Taraka", "Tubaran", "Tugaya", "Wao", "Abuyog", "Alangalang", "Albuera", "Babatngon", "Barugo", "Bato", "Burauen", "Calubian", "Capoocan", "Carigara", "Dagami", "Dulag", "Hilongos", "Hindang", "Inopacan", "Isabel", "Jaro", "Javier", "Julita", "Kananga", "La Paz", "Leyte", "MacArthur", "Mahaplag", "Matag-ob", "Matalom", "Mayorga", "Merida", "Palo", "Palompon", "Pastrana", "San Isidro", "San Miguel", "Santa Fe", "Tabango", "Tabontabon", "Tanauan", "Tolosa", "Tunga", "Villaba", "Ampatuan", "Barira", "Buldon", "Buluan", "Datu Abdullah Sangki", "Datu Anggal Midtimbang", "Datu Blah T. Sinsuat", "Datu Hoffer Ampatuan", "Datu Montawal", "Datu Odin Sinsuat", "Datu Paglas", "Datu Piang", "Datu Salibo", "Datu Saudi-Ampatuan", "Datu Unsay", "General Salipada K. Pendatun", "Guindulungan", "Kabuntalan", "Mamasapano", "Mangudadatu", "Matanog", "Northern Kabuntalan", "Pagalungan", "Paglat", "Pandag", "Parang", "Rajah Buayan", "Shariff Aguak", "Shariff Saydona Mustapha", "South Upi", "Sultan Kudarat", "Sultan Mastura", "Sultan sa Barongis", "Sultan Sumagka", "Talayan", "Upi", "Boac", "Buenavista", "Gasan", "Mogpog", "Santa Cruz", "Torrijos", "Aroroy", "Baleno", "Balud", "Batuan", "Cataingan", "Cawayan", "Claveria", "Dimasalang", "Esperanza", "Mandaon", "Milagros", "Mobo", "Monreal", "Palanas", "Pio V. Corpuz", "Placer", "San Fernando", "San Jacinto", "San Pascual", "Uson", "Pateros", "Aloran", "Baliangao", "Bonifacio", "Calamba", "Clarin", "Concepcion", "Don Victoriano Chiongbian", "Jimenez", "Lopez Jaena", "Panaon", "Plaridel", "Sapang Dalaga", "Sinacaban", "Tudela", "Alubijid", "Balingasag", "Balingoan", "Binuangan", "Claveria", "Gitagum", "Initao", "Jasaan", "Kinoguitan", "Lagonglong", "Laguindingan", "Libertad", "Lugait", "Magsaysay", "Manticao", "Medina", "Naawan", "Opol", "Salay", "Sugbongcogon", "Tagoloan", "Talisayan", "Villanueva", "Barlig", "Bauko", "Besao", "Bontoc", "Natonin", "Paracelis", "Sabangan", "Sadanga", "Sagada", "Tadian", "Binalbagan", "Calatrava", "Candoni", "Cauayan", "Enrique B. Magalona", "Hinigaran", "Hinoba-an", "Ilog", "Isabela", "La Castellana", "Manapla", "Moises Padilla", "Murcia", "Pontevedra", "Pulupandan", "Salvador Benedicto", "San Enrique", "Toboso", "Valladolid", "Amlan", "Ayungon", "Bacong", "Basay", "Bindoy", "Dauin", "Jimalalud", "La Libertad", "Mabinay", "Manjuyod", "Pamplona", "San Jose", "Santa Catalina", "Siaton", "Sibulan", "Tayasan", "Valencia", "Vallehermoso", "Zamboanguita", "Allen", "Biri", "Bobon", "Capul", "Catarman", "Catubig", "Gamay", "Laoang", "Lapinig", "Las Navas", "Lavezares", "Lope de Vega", "Mapanas", "Mondragon", "Palapag", "Pambujan"})
        Me.citycmb.Location = New System.Drawing.Point(751, 37)
        Me.citycmb.Name = "citycmb"
        Me.citycmb.Size = New System.Drawing.Size(200, 23)
        Me.citycmb.TabIndex = 2
        '
        'provcmb
        '
        Me.provcmb.FormattingEnabled = True
        Me.provcmb.Items.AddRange(New Object() {"Abra", "Agusan del Norte", "Agusan del Sur", "Aklan", "Albay", "Antique", "Apayao", "Aurora", "Basilan", "Bataan", "Batanes", "Batangas", "Benguet", "Biliran", "Bohol", "Bukidnon", "Bulacan", "Cagayan", "Camarines Norte", "Camarines Sur", "Camiguin", "Capiz", "Catanduanes", "Cavite", "Cebu", "Compostela Valley", "Cotabato", "Davao del Norte", "Davao del Sur", "Davao Occidental", "Davao Oriental", "Dinagat Islands", "Eastern Samar", "Guimaras", "Ifugao", "Ilocos Norte", "Ilocos Sur", "Iloilo", "Isabela", "Kalinga", "La Union", "Laguna", "Lanao del Norte", "Lanao del Sur", "Leyte", "Maguindanao", "Marinduque", "Masbate", "Misamis Occidental", "Misamis Oriental", "Mountain Province", "Negros Occidental", "Negros Oriental", "Northern Samar", "Nueva Ecija", "Nueva Vizcaya", "Occidental Mindoro", "Oriental Mindoro", "Palawan", "Pampanga", "Pangasinan", "Quezon", "Quirino", "Rizal", "Romblon", "Samar", "Sarangani", "Siquijor", "Sorsogon", "South Cotabato", "Southern Leyte", "Sultan Kudarat", "Sulu", "Surigao del Norte", "Surigao del Sur", "Tarlac", "Tawi-Tawi", "Zambales", "Zamboanga del Norte", "Zamboanga del Sur", "Zamboanga Sibugay", "CaMaNaVa", "PasMak", "PaMaMariSan", "MuntiParLasTaPat"})
        Me.provcmb.Location = New System.Drawing.Point(405, 37)
        Me.provcmb.Name = "provcmb"
        Me.provcmb.Size = New System.Drawing.Size(200, 23)
        Me.provcmb.TabIndex = 1
        '
        'regcmb
        '
        Me.regcmb.FormattingEnabled = True
        Me.regcmb.Items.AddRange(New Object() {"NCR", "CAR", "Region I", "Region II", "Region III", "Region IV-A", "Region IV-B", "Region IX", "Region V", "Region VI", "Region VII", "Region VIII", "Region X", "Region XI", "Region XII", "Region XIII", "ARMM"})
        Me.regcmb.Location = New System.Drawing.Point(64, 37)
        Me.regcmb.Name = "regcmb"
        Me.regcmb.Size = New System.Drawing.Size(200, 23)
        Me.regcmb.TabIndex = 0
        '
        'VIEWBTN
        '
        Me.VIEWBTN.Location = New System.Drawing.Point(848, 538)
        Me.VIEWBTN.Name = "VIEWBTN"
        Me.VIEWBTN.Size = New System.Drawing.Size(133, 40)
        Me.VIEWBTN.TabIndex = 23
        Me.VIEWBTN.Text = "VIEW"
        Me.VIEWBTN.UseVisualStyleBackColor = True
        '
        'fillbtn
        '
        Me.fillbtn.Location = New System.Drawing.Point(12, 541)
        Me.fillbtn.Name = "fillbtn"
        Me.fillbtn.Size = New System.Drawing.Size(136, 35)
        Me.fillbtn.TabIndex = 24
        Me.fillbtn.Text = "filter"
        Me.fillbtn.UseVisualStyleBackColor = True
        '
        'InstitutionMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(993, 582)
        Me.Controls.Add(Me.fillbtn)
        Me.Controls.Add(Me.VIEWBTN)
        Me.Controls.Add(Me.FIlterGB)
        Me.Controls.Add(Me.userstrip)
        Me.Controls.Add(Me.logbtn)
        Me.Controls.Add(Me.usrbtn)
        Me.Controls.Add(Me.intsbtn)
        Me.Controls.Add(Me.filebtn)
        Me.Controls.Add(Me.InstitutionVIew)
        Me.Name = "InstitutionMain"
        Me.Text = "InstitutionMain"
        Me.userstrip.ResumeLayout(False)
        CType(Me.InstitutionVIew, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FIlterGB.ResumeLayout(False)
        Me.FIlterGB.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents userstrip As Panel
    Friend WithEvents editbtn As Button
    Friend WithEvents addbtn As Button
    Friend WithEvents logbtn As Button
    Friend WithEvents usrbtn As Button
    Friend WithEvents intsbtn As Button
    Friend WithEvents filebtn As Button
    Friend WithEvents InstitutionVIew As DataGridView
    Friend WithEvents FIlterGB As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents citycmb As ComboBox
    Friend WithEvents provcmb As ComboBox
    Friend WithEvents regcmb As ComboBox
    Friend WithEvents VIEWBTN As Button
    Friend WithEvents fillbtn As Button
End Class
