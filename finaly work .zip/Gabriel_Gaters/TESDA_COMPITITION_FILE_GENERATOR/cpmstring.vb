﻿Imports System.Data.SqlClient
Module cpmstring
    Friend constr As String = "Data Source=DESKTOP-2PRLJCT;Initial Catalog=Module1;Integrated Security=True"
    Friend m2 As String = "Data Source=DESKTOP-2PRLJCT;Initial Catalog=Module2;Integrated Security=True"
    Friend m3 As String = "Data Source=DESKTOP-2PRLJCT;Initial Catalog=Module3;Integrated Security=True"
    Friend con As New SqlConnection(constr)
    Friend com As New SqlCommand


End Module
