﻿Imports System.IO

Public Class addtrainer
    Friend QUALIID As Integer



    Private Sub qtcmb_SelectedIndexChanged(sender As Object, e As EventArgs) Handles qtcmb.SelectedIndexChanged
        con = New SqlClient.SqlConnection(m3)

        Dim sql As String = "select id from Qualifications where QualificationName = '" + qtcmb.Text + "'"

        com = New SqlClient.SqlCommand(sql, con)
        Dim mr As SqlClient.SqlDataReader
        con.Open()

        mr = com.ExecuteReader
        mr.Read()
        QUALIID = mr("id")

    End Sub

    Private Sub addbtn_Click(sender As Object, e As EventArgs) Handles addbtn.Click
        con = New SqlClient.SqlConnection(m3)
        con.Open()
        com = con.CreateCommand
        com.CommandType = CommandType.Text

        Try
            com.CommandText = "insert into Trainers (TrainerName,NTTCNo,Validity,ContactInfo,EducationalAttainment,DateOfBirth,TrainerPicture,TrainerAddress,InstitutionID,QualificationID)" &
                            " values (@tn,@nn,@val,@ci,@ea,@db,@tp,@ta,@iid,@qid) "

            With com.Parameters
                .AddWithValue("@tn", nttxt.Text)
                .AddWithValue("@nn", nntxt.Text)
                .AddWithValue("@val", valitxt.Value.ToString)
                .AddWithValue("@ci", cntxt.Text)
                .AddWithValue("@ea", eatxt.Text)
                .AddWithValue("@db", bddate.Value.ToString)
                .AddWithValue("@tp", imagetxt.Text)
                .AddWithValue("@ta", addtxt.Text)
                '  .AddWithValue("@iid", )
                .AddWithValue("@qid", QUALIID)

            End With
            com.ExecuteNonQuery()
            con.Close()


        Catch ex As Exception
            MsgBox(ex.ToString)
            con.Close()

        End Try
    End Sub

    Private Sub brwsbtn_Click(sender As Object, e As EventArgs) Handles brwsbtn.Click
        Dim imgd As New OpenFileDialog

        imgd.FileName = ""
        imgd.Filter = "JPG FILES(*.jpg) |*.jpg"

        If imgd.ShowDialog = Windows.Forms.DialogResult.OK Then
            '  imagetxt.Text = Image.FromFile(imgd.FileName).ToString
            imagetxt.Text = imgd.FileName


        End If

    End Sub

    Private Sub addtrainer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim btn As New DataGridViewButtonColumn()
        trainersViewer.Columns.Add(btn)

        btn.Text = "REMOVE"
        btn.DefaultCellStyle.BackColor = Color.Red
        btn.DefaultCellStyle.ForeColor = Color.White

        btn.UseColumnTextForButtonValue = True

        viewload()


    End Sub
    Public Sub viewload()
        con = New SqlClient.SqlConnection(m3)
        Dim sql As String = "select TrainerName,NTTCNo from Trainers"
        Dim adp As New SqlClient.SqlDataAdapter(sql, con)
        Dim ds As New DataSet

        adp.Fill(ds, "Trainers")

        trainersViewer.DataSource = ds.Tables(0)
    End Sub
End Class