﻿Public Class mainform
    Dim ds As New DataSet
    Dim numID As Integer
    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs)

    End Sub

    Private Sub usrbtn_Click(sender As Object, e As EventArgs) Handles usrbtn.Click
        If userstrip.Visible = False Then
            userstrip.Visible = True
        Else
            userstrip.Visible = False
        End If


    End Sub

    Private Sub srchbtn_Click(sender As Object, e As EventArgs) Handles srchbtn.Click
        con.Open()
        Dim sql As String = "select Users.Email, Users.FristName, Users.LastName ,Roles.RoleType ,Users.Office ,Users.Active" &
         "from (Users inner join Roles on Roles.id = Users.RolesID)"
        sql &= "where FirstName = '" + +"'"
        sql &= "or LastName = '" + srchtxt.Text + "'"

        Dim da As New SqlClient.SqlDataAdapter(sql, con)
        Dim ds As New DataSet

        da.fill(ds)


        UsersView.DataSource = ds.Tables(0)



    End Sub

    Private Sub addbtn_Click(sender As Object, e As EventArgs) Handles addbtn.Click
        addfrm.Show()
        Me.Hide()

    End Sub

    Private Sub editbtn_Click(sender As Object, e As EventArgs) Handles editbtn.Click
        editfrm.Show()
        Me.Hide()

    End Sub

    Private Sub mainform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '    Label2.Text = log_infrm.IDI

        loadview()
    End Sub

    Public Sub loadview()
        Try
            con = New SqlClient.SqlConnection(constr)
            Dim cons As String = "select  Users.FirstName, Users.LastName,Users.Email, Users.Office ,Users.Active from  Users   "
            Dim adapt As New SqlClient.SqlDataAdapter(cons, con)
            Dim ds As New DataSet
            adapt.Fill(ds)
            UsersView.DataSource = ds.Tables(0)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub enblbtn_Click(sender As Object, e As EventArgs) Handles enblbtn.Click

    End Sub

    Private Sub UsersView_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles UsersView.CellClick
        '  numID = UsersView.SelectedRows.Item(0).ToString()
        For Each rows As DataGridViewRow In UsersView.Rows
            If rows.Cells("Active").Value = 0 Then
                enblbtn.Text = "Enable"
            ElseIf rows.Cells("Active").Value = 1 Then
                enblbtn.Text = "Disable"
            End If
        Next




    End Sub

    Private Sub UsersView_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles UsersView.CellFormatting
        For Each rows As DataGridViewRow In UsersView.Rows
            If rows.Cells("Active").Value = "0" Then
                rows.DefaultCellStyle.BackColor = Color.Red

            End If
        Next

    End Sub

    Private Sub intsbtn_Click(sender As Object, e As EventArgs) Handles intsbtn.Click
        InstitutionMain.Show()
        Me.Hide()

    End Sub
End Class