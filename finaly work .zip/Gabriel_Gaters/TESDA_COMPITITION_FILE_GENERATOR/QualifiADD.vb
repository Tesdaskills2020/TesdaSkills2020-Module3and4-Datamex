﻿Public Class QualifiADD
    Friend quali As Integer

    Private Sub DomainUpDown1_SelectedItemChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub QUALIVIEW_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles QUALIVIEW.CellContentClick
        If e.ColumnIndex <> 0 Then
            MsgBox("wrong")

        End If

        MsgBox("right")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click


        con = New SqlClient.SqlConnection(m3)
        con.Open()
        com = con.CreateCommand
        com.CommandType = CommandType.Text
        Dim InstituteID As Integer = InstitutionsViewinfo.iden


        Try
            com.CommandText = "Insert int RegisteredPrograms (ProgramRegistrationNumber,DateIssued,Duration,ProgramStatus,NumberOfWorkShop,NumberOFTrainees,NumberOfBratches,QualificationsID,InstitutoinID) values (@qt,@prn,@di,@d,@ps,@nw,@nt,@nb,@qid,@iid)"
            With com.Parameters
                .AddWithValue("@qt", QTCMB.Text)
                .AddWithValue("@prn", PRNTXT.Text)
                .AddWithValue("@di", DIDP.Value.ToString)
                .AddWithValue("@ps", PSCMB.Text)
                .AddWithValue("@nw", NWTXT.Text)
                .AddWithValue("@nb", NBTXT.Text)
                .AddWithValue("@qid", quali)
                .AddWithValue("@iid", InstituteID)



            End With
            com.ExecuteNonQuery()

            con.Close()


        Catch ex As Exception
            MsgBox(ex.ToString)
            con.Close()

        End Try
    End Sub

    Private Sub QTCMB_SelectedIndexChanged(sender As Object, e As EventArgs) Handles QTCMB.SelectedIndexChanged
        con = New SqlClient.SqlConnection(m3)

        Dim sql As String = "select id from Qualifications where QualificationName = '" + QTCMB.Text + "'"

        com = New SqlClient.SqlCommand(sql, con)
        Dim mr As SqlClient.SqlDataReader
        con.Open()

        mr = com.ExecuteReader
        mr.Read()

        '  MsgBox(mr("id"))
        quali = mr("id")
    End Sub

    Private Sub QualifiADD_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim btn As New DataGridViewButtonColumn()
        QUALIVIEW.Columns.Add(btn)

        btn.Text = "remove"
        btn.DefaultCellStyle.BackColor = Color.Red
        btn.DefaultCellStyle.ForeColor = Color.White

        btn.UseColumnTextForButtonValue = True


        loadview()



    End Sub
    Public Sub loadview()
        con = New SqlClient.SqlConnection(m3)
        con.Open()

        Dim sql As String = "Select id, ProgramRegistrationNumber from RegisteredPrograms "
        Dim adpt As New SqlClient.SqlDataAdapter(sql, con)
        Dim ds As New DataSet
        adpt.Fill(ds, "RegisteredPrograms")

        QUALIVIEW.DataSource = ds.Tables(0)
    End Sub
End Class