﻿Imports System.IO
Public Class addtinsti

    Dim trans As SqlClient.SqlTransaction
    Dim ms As New MemoryStream
    Dim OD As OpenFileDialog



    Private Sub savebtn_Click(sender As Object, e As EventArgs) Handles savebtn.Click
        con = New SqlClient.SqlConnection(m2)
        con.Open()
        com = con.CreateCommand
        com.CommandType = CommandType.Text

        Dim rid As Integer = +1
        trans = con.BeginTransaction(IsolationLevel.ReadCommitted)
        com.Connection = con
        com.Transaction = trans

        Try
            com.CommandText = "Insert into Institutoins(InstitutionName,Address,AdminName,Designation,EmailAddress,TelNo,Classification,InstitutionType,) values (@IN,@A,@AN,@D,@EA,@TN,@C,@IT)"
            With com.Parameters
                .AddWithValue("@IN", nicmb.Text)
                .AddWithValue("@A", addresstxt.Text)
                .AddWithValue("@AN", admntxt.Text)
                .AddWithValue("@D", DSGTXT.Text)
                .AddWithValue("@EA", emtxt.Text)
                .AddWithValue("@TN", tntxt.Text)
                .AddWithValue("@C", cicmb.Text)
                .AddWithValue("@IT", ticmb.Text)

            End With
            com.ExecuteNonQuery()

            com.CommandText = "insert into Region (Name) values(@N)"
            com.Parameters.AddWithValue("@N", regcmb.Text)
            com.ExecuteNonQuery()


            com.CommandText = "insert into Province (Name,RegionID) values(@n,@rid)"
            com.Parameters.AddWithValue("@n", provcmb.Text)
            com.Parameters.AddWithValue("@rid", rid)
            com.ExecuteNonQuery()

            com.CommandText = "insert into Municipality (City,DistricNumber,ProvinceID) values (@city,@DN,@pid)"
            With com.Parameters
                .AddWithValue("@city", cicmb.Text)
                .AddWithValue("@DN", DSTRCTCMB.Text)
                .AddWithValue("@pid", rid)

            End With
            com.ExecuteNonQuery()

            MsgBox("recorded sucesfully")

            trans.Commit()
            con.Close()


        Catch ex As Exception
            MsgBox(ex.ToString)
            con.Close()

        Finally
            con.Close()

        End Try



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        OD.FileName = ""
        OD.Filter = "(*jpg,*png) | *jpg , *png"
        If OD.ShowDialog = DialogResult.OK Then
            logobox.Image = Image.FromFile(OD.FileName)

        End If

    End Sub


End Class