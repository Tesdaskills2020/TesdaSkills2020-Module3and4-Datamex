﻿Public Class log_infrm
    Friend IDI As Integer


    Private Sub savebtn_Click(sender As Object, e As EventArgs) Handles savebtn.Click
        con.Open()

        Dim sql As String = "select * from dbo.Users Where Email='" + untxt.Text + "' and Password= '" + pwdtxt.Text + "'"
        Dim adpt As New SqlClient.SqlDataAdapter(sql, con)

        Dim dt As New DataTable
        adpt.Fill(dt)
        com = New SqlClient.SqlCommand(sql, con)
        Dim mr As SqlClient.SqlDataReader
        mr = com.ExecuteReader
        mr.Read()


        Try
            If (dt.Rows.Count > 0) Then
                MsgBox("login succesully")
                IDI = mr("RoleID")
                ' InstitutionMain.Show()
                mainform.Show()



            Else
                MsgBox("log-in failed")

            End If
            con.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
            con.Close()
        Finally
            con.Close()
        End Try



    End Sub
End Class
