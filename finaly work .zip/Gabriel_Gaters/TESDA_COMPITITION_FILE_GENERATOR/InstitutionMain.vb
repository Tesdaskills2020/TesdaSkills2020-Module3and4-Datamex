﻿Public Class InstitutionMain
    Dim idn As String

    Private Sub InstitutionMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' loadview()
    End Sub
    Public Sub loadview()
        con = New SqlClient.SqlConnection(m2)
        Dim sql As String = "select Region.Name, Province.Name, Municipality.id, Institutions.InstitutionName  from Region inner join Province on Region.ID = Province.RegionID inner join dbo.Municipality  on   Province.ID = Municipality.ProvinceID   inner join Institutions on  Municipality.id = Institutions.MunicipalityID   "
        Dim sqll As String = "select Region.Name,Province.Name,Institutions.InstitutionName"
        Dim adpt As New SqlClient.SqlDataAdapter(sqll, con)
        Dim ds As New DataSet

        adpt.Fill(ds)




        InstitutionVIew.DataSource = ds.Tables(0)
        '    InstitutionVIew.Columns("id").Visible = False
        InstitutionVIew.Columns("name").HeaderText = "REGION"
        InstitutionVIew.Columns("name1").HeaderText = "PROVINCE"
        InstitutionVIew.Columns("InstitutionName").HeaderText = "NAME OF INSTITUTOIN"









    End Sub

    Private Sub addbtn_Click(sender As Object, e As EventArgs) Handles addbtn.Click
        addfrm.Show()
        Me.Hide()

    End Sub

    Private Sub editbtn_Click(sender As Object, e As EventArgs) Handles editbtn.Click
        editfrm.Show()
        Me.Hide()

    End Sub
    Private Sub usrbtn_Click(sender As Object, e As EventArgs) Handles usrbtn.Click
        If userstrip.Visible = False Then
            userstrip.Visible = True
        Else
            userstrip.Visible = False
        End If


    End Sub

    Private Sub logbtn_Click(sender As Object, e As EventArgs) Handles logbtn.Click

    End Sub

    Private Sub InstitutionVIew_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles InstitutionVIew.CellContentClick

    End Sub

    Private Sub regcmb_SelectedIndexChanged(sender As Object, e As EventArgs) Handles regcmb.SelectedIndexChanged
        con = New SqlClient.SqlConnection(m2)



    End Sub

    Private Sub VIEWBTN_Click(sender As Object, e As EventArgs) Handles VIEWBTN.Click
        InstitutionsViewinfo.Show()
        Me.Hide()

    End Sub
    Public Sub srchfr()
        Try
            Dim sql As String = " select Region.id, Region.Name, Province.Name, Municipality.id,Institutions.InstitutionName ,Institutions.InstitutionLogo "
            sql &= "from Region inner join Province on Province(RegionID) = Region(id) "
            sql &= "Province Inner Join Municipality on Municipality(ProvinveID) = Province(id) "
            sql &= "Municipality Inner Join Institutions on Institution(MunicipalityID) = Municipality(ID)"
            sql &= "where Region.Name ='%' +@sqlr+ '%' "
            '   sql &= "where Province.Name = '%' +@sqlp+ '%' "
            '   sql &= "where Municipality.City  = '%' +@sqlin+ '%'"

            con = New SqlClient.SqlConnection(m2)
            com = New SqlClient.SqlCommand(sql, con)

            com.Parameters.AddWithValue("@sqlr", regcmb.Text)
            Dim da As New SqlClient.SqlDataAdapter(com)
            Dim dt As New DataSet
            da.Fill(dt)
            InstitutionVIew.DataSource = dt.Tables(0)
            '  Return (dt)


            Dim mr As SqlClient.SqlDataReader

            mr = com.ExecuteReader
            mr.Read()

            idn = mr("id")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Private Sub fillbtn_Click(sender As Object, e As EventArgs) Handles fillbtn.Click
        '  srchfr()

    End Sub
End Class