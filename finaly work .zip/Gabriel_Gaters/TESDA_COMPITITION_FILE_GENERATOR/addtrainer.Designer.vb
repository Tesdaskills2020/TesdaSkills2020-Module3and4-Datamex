﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class addtrainer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.bddate = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.addtxt = New System.Windows.Forms.TextBox()
        Me.eatxt = New System.Windows.Forms.TextBox()
        Me.cntxt = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.addbtn = New System.Windows.Forms.Button()
        Me.brwsbtn = New System.Windows.Forms.Button()
        Me.imagetxt = New System.Windows.Forms.TextBox()
        Me.valitxt = New System.Windows.Forms.DateTimePicker()
        Me.nntxt = New System.Windows.Forms.TextBox()
        Me.nttxt = New System.Windows.Forms.TextBox()
        Me.qtcmb = New System.Windows.Forms.ComboBox()
        Me.trainersViewer = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.trainersViewer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.bddate)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.addtxt)
        Me.GroupBox1.Controls.Add(Me.eatxt)
        Me.GroupBox1.Controls.Add(Me.cntxt)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.addbtn)
        Me.GroupBox1.Controls.Add(Me.brwsbtn)
        Me.GroupBox1.Controls.Add(Me.imagetxt)
        Me.GroupBox1.Controls.Add(Me.valitxt)
        Me.GroupBox1.Controls.Add(Me.nntxt)
        Me.GroupBox1.Controls.Add(Me.nttxt)
        Me.GroupBox1.Controls.Add(Me.qtcmb)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(738, 644)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "TRANER DETAILS"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(161, 348)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(120, 25)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "BIRTH DATE"
        '
        'bddate
        '
        Me.bddate.CustomFormat = ""
        Me.bddate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.bddate.Location = New System.Drawing.Point(299, 348)
        Me.bddate.Name = "bddate"
        Me.bddate.Size = New System.Drawing.Size(354, 33)
        Me.bddate.TabIndex = 19
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(184, 285)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(97, 25)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "ADDRESS"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 226)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(269, 25)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "EDUCATIONAL ATTAINMENT"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(147, 171)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(134, 25)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "CONTACT nO."
        '
        'addtxt
        '
        Me.addtxt.Location = New System.Drawing.Point(299, 282)
        Me.addtxt.Name = "addtxt"
        Me.addtxt.Size = New System.Drawing.Size(354, 33)
        Me.addtxt.TabIndex = 14
        '
        'eatxt
        '
        Me.eatxt.Location = New System.Drawing.Point(299, 223)
        Me.eatxt.Name = "eatxt"
        Me.eatxt.Size = New System.Drawing.Size(354, 33)
        Me.eatxt.TabIndex = 13
        '
        'cntxt
        '
        Me.cntxt.Location = New System.Drawing.Point(299, 163)
        Me.cntxt.Name = "cntxt"
        Me.cntxt.Size = New System.Drawing.Size(354, 33)
        Me.cntxt.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(208, 537)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 25)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "IMAGE"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(185, 472)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(96, 25)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "VALITIDY"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(183, 414)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 25)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "NTTC NO."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(100, 105)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(181, 25)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "NAME OF TRAINER"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(73, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(208, 25)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "QUALIFICATION TITLE"
        '
        'addbtn
        '
        Me.addbtn.Location = New System.Drawing.Point(466, 584)
        Me.addbtn.Name = "addbtn"
        Me.addbtn.Size = New System.Drawing.Size(187, 41)
        Me.addbtn.TabIndex = 6
        Me.addbtn.Text = "&ADD TRAINER"
        Me.addbtn.UseVisualStyleBackColor = True
        '
        'brwsbtn
        '
        Me.brwsbtn.Location = New System.Drawing.Point(520, 533)
        Me.brwsbtn.Name = "brwsbtn"
        Me.brwsbtn.Size = New System.Drawing.Size(133, 33)
        Me.brwsbtn.TabIndex = 5
        Me.brwsbtn.Text = "&BROWSE"
        Me.brwsbtn.UseVisualStyleBackColor = True
        '
        'imagetxt
        '
        Me.imagetxt.Location = New System.Drawing.Point(299, 533)
        Me.imagetxt.Name = "imagetxt"
        Me.imagetxt.Size = New System.Drawing.Size(181, 33)
        Me.imagetxt.TabIndex = 4
        '
        'valitxt
        '
        Me.valitxt.Location = New System.Drawing.Point(299, 472)
        Me.valitxt.Name = "valitxt"
        Me.valitxt.Size = New System.Drawing.Size(354, 33)
        Me.valitxt.TabIndex = 3
        '
        'nntxt
        '
        Me.nntxt.Location = New System.Drawing.Point(299, 414)
        Me.nntxt.Name = "nntxt"
        Me.nntxt.Size = New System.Drawing.Size(354, 33)
        Me.nntxt.TabIndex = 2
        '
        'nttxt
        '
        Me.nttxt.Location = New System.Drawing.Point(299, 105)
        Me.nttxt.Name = "nttxt"
        Me.nttxt.Size = New System.Drawing.Size(354, 33)
        Me.nttxt.TabIndex = 1
        '
        'qtcmb
        '
        Me.qtcmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.qtcmb.FormattingEnabled = True
        Me.qtcmb.Items.AddRange(New Object() {"2D Animation NC III", "2D Game Art Development NC III", "3D Animation NC III", "3D Game Art Development NC III", "Able Seafarer Deck NC II (STCW Regulation II/5) ", "Able Seafarer Engine NC II (STCW Regulation III/5)", "Agricultural Crops Production NC I", "Agricultural Crops Production NC II", "Agricultural Crops Production NC III", "Agricultural Machinery Operation NC II", "Agroentrepreneurship NC II", "Agroentrepreneurship NC III", "Agroentrepreneurship NC IV", "Air Duct Servicing NC II", "Animal Health Care and Management NC III", "Animal Production (Poultry-Chicken) NC II", "Animal Production (Ruminants) NC II", "Animal Production (Swine) NC II", "Animation NC II", "Aquaculture NC II", "Artificial Insemination (Large Ruminants) NC II", "Artificial Insemination (Swine) NC II", "Attraction & Theme Parks Operation NC II", "Auto Engine Rebuilding NC II", "Automotive Body Painting/Finishing NC I", "Automotive Body Painting/Finishing NC II", "Automotive Body Painting/Finishing NC III", "Automotive Body Repairing NC II", "Automotive Electrical Assembly NC II", "Automotive Electrical Assembly NC III", "Automotive Mechanical Assembly NC II", "Automotive Mechanical Assembly NC III", "Automotive Servicing NC I", "Automotive Servicing NC II", "Automotive Servicing NC III", "Automotive Servicing NC IV", "Automotive Wiring Harness Assembly NC II", "Bamboo Production NC II", "Barangay Health Services NC II", "Barbering NC II", "Barista NC II", "Bartending NC II", "Beauty Care NC II", "Beauty Care NC III", "Beauty Care Services (Nail Care) NC II", "Beauty Care Services (Nail Care) NC III", "Biomedical Equipment Services NC II", "Bookkeeping NC III", "Bread and Pastry Production NC II", "Broadband Installation (Fixed Wireless Systems) NC II", "Cable TV (CATV) Installation NC II", "Cable TV (CATV) Operation and Maintenance NC III", "CAD/CAM Operation NC III", "Caregiving NC II", "Carpentry NC II", "Carpentry NC III", "Chemical Process Operations NC III", "CNC Lathe Machine Operation NC II", "CNC Lathe Machine Operation NC III", "CNC Milling Machine Operation NC II", "CNC Milling Machine Operation NC III", "Commercial Cooking NC II", "Commercial Cooking NC III", "Commercial Cooking NC IV", "Computer Hardware Servicing NC II", "Computer Systems Servicing NC II", "Construction Lift Passenger/ Material Elevator Operation NC II", "Construction Painting NC II", "Construction Painting NC III", "Consumer Electronics Servicing NC III", "Consumer Electronics Servicing NC IV", "Contact Center Services NC II", "Cookery NC II", "Customer Services NC II", "Dental Hygiene NC IV", "Dental Laboratory Technology Services (Fixed Dentures/Restorations) NC II", "Dental Laboratory Technology Services (Removable Dentures/Appliances) NC II", "Dental Laboratory Technology Services NC I", "Dental Technology NC IV", "Diesel Power Plant Maintenance NC III", "Diesel Power Plant Operation and Maintenance NC II", "Diesel Power Plant Operation and Maintenance NC III", "Domestic Work NC II", "Dressmaking NC II", "Driving (Articulated Vehicle) NC III", "Driving (Passenger Bus/Straight Truck) NC III", "Driving NC II", "Drying and Milling Plant Servicing NC III", "Electric Power Distribution Line Construction NC II", "Electric Power Distribution Operation and Maintenance NC III", "Electric Power Distribution Operation and Maintenance NC IV", "Electrical Installation and Maintenance NC II", "Electrical Installation and Maintenance NC III", "Electrical Installation and Maintenance NC IV", "Electronics Back-End Operation NC II", "Electronics Front-of-Line Operation NC II", "Electronics Products Assembly and Servicing NC II", "Electronics/Semiconductor Production Line Machine Servicing NC III", "Emergency Medical Services NC II", "Events Management Services NC III", "Fashion Design (Apparel) NC III", "Fish Capture NC I", "Fish Capture NC II", "Fish Products Packaging NC II", "Fishing Gear Repair and Maintenance NC III", "Fishport/Wharf Operation NC I", "Flux Cored Arc Welding (FCAW) NC I", "Flux Cored Arc Welding (FCAW) NC II", "Flux Cored Arc Welding (FCAW) NC III", "Food and Beverage Services NC II", "Food and Beverage Services NC III", "Food and Beverage Services NC IV", "Food Processing NC I", "Food Processing NC II", "Food Processing NC III", "Food Processing NC IV", "Footwear Making NC II", "Forging NC II", "Forging NC III", "Foundry Melting/Casting NC II", "Foundry Melting/Casting NC III", "Foundry Molding NC II", "Foundry Molding NC III", "Foundry Pattern Making NC II", "Foundry Pattern Making NC III", "Front Office Services NC II", "Furniture Making (Finishing) NC II", "Game Programming NC III", "Garbage Collection NC I", "Gas Metal Arc Welding (GMAW) NC I", "Gas Metal Arc Welding (GMAW) NC II", "Gas Metal Arc Welding (GMAW) NC III", "Gas Tungsten Arc Welding (GTAW) NC II", "Gas Tungsten Arc Welding (GTAW) NC IV", "Gas Welding NC I", "Gas Welding NC II", "Grains Production NC II", "Hairdressing NC II", "Hairdressing NC III", "Hard Disk Drive (HDD) Front-of-Line Operation NC II", "Health Care Services NC II", "Heat Treatment NC II", "Heavy Equipment Operation (Bulldozer) NC II", "Heavy Equipment Servicing (Mechanical) NC II", "Heavy Equipment Operation (Articulated Off-Highway Dump Truck) NC II", "Heavy Equipment Operation (Backhoe Loader) NC II", "Heavy Equipment Operation (Concrete Pump) NC II", "Heavy Equipment Operation (Container Stacker) NC II", "Heavy Equipment Operation (Crawler Crane) NC II", "Heavy Equipment Operation (Forklift) NC II", "Heavy Equipment Operation (Gantry Crane) NC II", "Heavy Equipment Operation (Hydraulic Excavator) NC II", "Heavy Equipment Operation (Motor Grader) NC II", "Heavy Equipment Operation (Paver) NC II", "Heavy Equipment Operation (Rigid Off-Highway Dump Truck) NC II", "Heavy Equipment Operation (Rigid On-Highway Dump Truck) NC II", "Heavy Equipment Operation (Road Roller) NC II", "Heavy Equipment Operation (Rough Terrain Crane) NC II", "Heavy Equipment Operation (Screed) NC I", "Heavy Equipment Operation (Tower Crane) NC II", "Heavy Equipment Operation (Transit Mixer) NC II", "Heavy Equipment Operation (Truck Mounted Crane) NC II", "Heavy Equipment Operation (Wheel Loader) NC II", "Hilot (Wellness Massage) NC II", "Horticulture NC II", "Horticulture NC III", "Household Services NC II", "Housekeeping NC II", "Housekeeping NC III", "Housekeeping NC IV", "Ice Plant Refrigeration Servicing NC III", "Illustration NC II", "Instrumentation and Control Servicing NC II", "Instrumentation and Control Servicing NC III", "Instrumentation and Control Servicing NC IV", "Jewelry Making (Fine Jewelry) NC II", "Jewelry Making (Fine Jewelry) NC III", "Laboratory and Metrology/Calibration NC II", "Laboratory and Metrology/Calibration NC III", "Land-based Transport Refrigeration Servicing NC II", "Landscape Installation and Maintenance (Softscape) NC II", "Lifeguard Services NC II", "Lifeguard Services NC III", "LINE CONSTRUCTION  (ELECTRIC POWER DISTRIBUTION) NC II", "Local Guiding Services NC II", "Machining NC I", "Machining NC II", "Machining NC III", "Marine Electricity NC II", "Masonry NC I", "Masonry NC II", "Masonry NC III", "Massage Therapy NC II", "Mechanical Drafting NC I", "Mechatronics Servicing NC II", "Mechatronics Servicing NC III", "Mechatronics Servicing NC IV", "Medical Coding and Billing NC II", "Medical Coding and Claims Processing NC III", "Medical Transcription NC II", "Metal Stamping NC II", "Microfinance Technology NC II", "Microfinance Technology NC IV", "Milking Operation NC II", "Mold Making NC II", "Motorcycle/ Small Engine Servicing NC II", "Ophthalmic Lens Services NC II", "Organic Agriculture Production NC II", "Painting Machine Operation NC II", "Performing Arts (Ballroom Dancing) NC II", "Performing Arts (Dance) NC II", "Performing Arts (Song) NC II", "Pest Management (Vegetables) NC II", "Pharmacy Services NC II", "Pharmacy Services NC III", "Photography NC II", "Pipefitting (Metallic) NC II", "Pipefitting NC II", "Plant Maintenance NC I", "Plastic Machine Operation NC II", "Plastic Machine Operation NC III", "Plumbing NC I", "Plumbing NC II", "Plumbing NC III", "Press Machine Operation NC I", "Process Inspection NC II", "Process Inspection NC III", "Programming (.Net Technology) NC III", "Programming (Java) NC III", "Programming (Oracle Database) NC III", "Programming NC IV", "PV System Design NC III", "PV Systems Installation NC II", "PV Systems Servicing NC III", "Pyrotechnics NC II", "RAC Servicing (DomRAC) NC II", "RAC Servicing (PACU-CRE) NC III", "Rating Forming Part of Engineering Watch NC II (STCW Regulation III/4) NC II", "Rating Forming Part of Navigational Watch NC II (STCW Regulation II/4) NC II", "Real Estate Services NC II", "Reinforcing Steel Works NC II", "Rice Machinery Operations NC II", "Rigging NC I", "Rubber Processing NC II", "Rubber Production NC II", "Sanitary Landfill Operations NC II", "Sanitary Landfill Operations NC III", "Scaffold Erection NC II", "Scaffolding Works NC II (Supported Type Scaffold)", "Seaweeds Production NC II", "Security Services NC I", "Security Services NC II", "Semiconductor Back-End Operation NC II", "Semiconductor Front-of-Line Operations NC II", "Shielded Metal Arc Welding (SMAW) NC I", "Shielded Metal Arc Welding (SMAW) NC II", "Shielded Metal Arc Welding (SMAW) NC III", "Shielded Metal Arc Welding (SMAW) NC IV", "Ships' Catering (Ships' Cooks) NC III", "Ship's Catering Services NC I", "Ship's Catering Services NC II", "Slaughtering Operations (Large Animal) NC II", "Slaughtering Operations (Swine) NC II", "Slaughtering Operations NC II", "Structural Erection NC II", "Submerged Arc Welding (SAW) NC I", "Submerged Arc Welding (SAW) NC II", "Sugarcane Production NC II", "System Formworks Installation NC II", "Tailoring NC II", "Technical Drafting NC II", "Telecom OSP and Subscriber Line Installation (Copper Cable/POTS and DSL) NC II", "Telecom OSP Installation (Fiber Optic Cable) NC II", "Tile Setting NC II", "Tinsmithing (Automotive Manufacturing) NC II", "Tool and Die Making NC II", "Tour Guiding Services NC II", "Tourism Promotion Services NC II", "Trainers Methodology Level (In-Company Trainer) I", "Trainers Methodology Level I", "Trainers Methodology Level II", "Transmission Line Installation and Maintenance NC II", "Transmission Line Installation and Maintenance NC III", "Transmission Line Installation and Maintenance NC IV", "Transport RAC Servicing NC II", "Travel Services NC II", "Visual Graphic Design NC III", "Warehousing Services NC II", "Web Development NC III"})
        Me.qtcmb.Location = New System.Drawing.Point(299, 45)
        Me.qtcmb.Name = "qtcmb"
        Me.qtcmb.Size = New System.Drawing.Size(354, 33)
        Me.qtcmb.TabIndex = 0
        '
        'trainersViewer
        '
        Me.trainersViewer.AllowUserToAddRows = False
        Me.trainersViewer.AllowUserToDeleteRows = False
        Me.trainersViewer.AllowUserToResizeColumns = False
        Me.trainersViewer.AllowUserToResizeRows = False
        Me.trainersViewer.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.trainersViewer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.trainersViewer.Dock = System.Windows.Forms.DockStyle.Top
        Me.trainersViewer.Location = New System.Drawing.Point(0, 644)
        Me.trainersViewer.Name = "trainersViewer"
        Me.trainersViewer.ReadOnly = True
        Me.trainersViewer.RowTemplate.Height = 25
        Me.trainersViewer.Size = New System.Drawing.Size(738, 206)
        Me.trainersViewer.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(621, 884)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 25)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "save"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(510, 884)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(105, 25)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "back"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'addtrainer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(738, 921)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.trainersViewer)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "addtrainer"
        Me.Text = "addtrainer"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.trainersViewer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label9 As Label
    Friend WithEvents bddate As DateTimePicker
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents addtxt As TextBox
    Friend WithEvents eatxt As TextBox
    Friend WithEvents cntxt As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents addbtn As Button
    Friend WithEvents brwsbtn As Button
    Friend WithEvents imagetxt As TextBox
    Friend WithEvents valitxt As DateTimePicker
    Friend WithEvents nntxt As TextBox
    Friend WithEvents nttxt As TextBox
    Friend WithEvents qtcmb As ComboBox
    Friend WithEvents trainersViewer As DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
